﻿function Index_Ready() {

    var sel = $("#body_id");
    if (sel != undefined)
        sel.css("border", "3px solid red");
}