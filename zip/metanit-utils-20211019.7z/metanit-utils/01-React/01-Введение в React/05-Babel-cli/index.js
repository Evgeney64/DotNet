class Hello extends React.Component {
  render() {
    return /*#__PURE__*/React.createElement("h1", null, "Hello, React");
  }

}

ReactDOM.render( /*#__PURE__*/React.createElement(Hello, null), document.getElementById("app"));
