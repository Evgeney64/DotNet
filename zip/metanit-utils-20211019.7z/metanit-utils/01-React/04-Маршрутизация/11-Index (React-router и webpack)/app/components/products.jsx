import React from 'react';
 
export default class Products extends React.Component{
    render(){
        return <h2>Товары</h2>;
    }
}