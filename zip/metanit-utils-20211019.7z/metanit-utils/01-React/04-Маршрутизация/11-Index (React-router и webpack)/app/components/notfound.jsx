import React from 'react';
 
export default class NotFound extends React.Component{
    render(){
        return <h2>Ресурс не найден</h2>;
    }
}