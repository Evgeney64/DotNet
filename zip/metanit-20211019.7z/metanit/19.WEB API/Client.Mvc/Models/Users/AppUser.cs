﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace ru.tsb.mvc.Models.Users
{
    public class AppUser : IdentityUser
    {
    }
}
